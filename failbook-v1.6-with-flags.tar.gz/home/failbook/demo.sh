#!/bin/bash

#while true; do ./userGen.sh -real -n 1 -l -p 1245066943 -t 192.168.1.134 -u; sleep 30; done;
while true; do ./userGen.sh -real -n 1 -t 192.168.1.134 -u; sleep 10; done;

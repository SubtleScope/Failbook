<?php
	print_r( apache_response_headers() );

	require( "index.html" );
?>

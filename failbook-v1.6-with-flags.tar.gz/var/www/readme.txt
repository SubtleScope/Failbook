to restore db:

mysql -u root --password failbook < ./failbook.sql

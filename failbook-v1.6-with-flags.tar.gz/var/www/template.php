<?php

echo "This is a test page to be deleted once operational"; 

?>

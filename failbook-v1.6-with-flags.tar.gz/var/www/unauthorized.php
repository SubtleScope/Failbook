<h3>Error: You are unauthorized to access this page.</h3> 
<hr />
<br /><br /> 
<h3>Silly mortal, only Tom can do that!</h3>
<br /><br />
<h3>Tom is the man, you can't hack his stuff!</h3>

<br /><br /><br />

err: insert into security_log failed ... mysql error (13); please check your syntax or the mysql manual for your mysql version
